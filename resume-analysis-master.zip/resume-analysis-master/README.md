# resume-analysis
Resume parsing, analysing, score and matching web application using python and django
