import pdftotext
import docx2txt
from django.shortcuts import render, redirect, get_object_or_404
from django.db.models import Q
from django.contrib import messages
from django.core.exceptions import PermissionDenied
from admins.models import Categories, Skills
from candidate.models import Resumes, Details
from pyresparser import ResumeParser
from account.models import AppUsers
import os
import nltk
nltk.download('stopwords')
from fuzzywuzzy import fuzz
from company.models import Posts

# Create your views here.

# Rounding off the values
def truncate(n, decimals=0):
    multiplier = 10 ** decimals
    return int(n * multiplier) / multiplier

def index(request):
    passdata = {}
    if(request.session.has_key('user_id')):
        if(request.session['role_id'] == 2):
            passdata['fullname'] = request.session['fullname']
            user_has_resume_uploaded = Resumes.objects.filter(Q(candidate_id = int(request.session['user_id'])))
            if(user_has_resume_uploaded.count() < 1):
                return redirect('/user/upload')
            else:
                # Get resume from projects directory
                BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                candidateresumee = Resumes.objects.get(candidate_id = int(request.session['user_id']))
                get_path = candidateresumee.resume_doc.url

                # Get file extension
                filename, file_extension = os.path.splitext(os.path.join(BASE_DIR, get_path[1:]))
                
                exttext = ''
                if(file_extension == '.docx'):
                    exttext = docx2txt.process(os.path.join(BASE_DIR, get_path[1:]))

                if(file_extension == '.pdf'):
                    pdf_raw = open(os.path.join(BASE_DIR, get_path[1:]), 'rb')
                    pdf_process = pdftotext.PDF(pdf_raw)
                    for pg in pdf_process:
                        exttext += pg
                    pdf_raw.close()

                matcheslist = []

                postall = Posts.objects.all().order_by('-ondate')
                for post in postall:
                    compnaydetails = AppUsers.objects.get(pk=post.company_id)
                    postskills = post.skills
                    postskillslist = list(postskills.split(','))
                    counter = 0
                    for skl in postskillslist:
                        if(skl.lower() in exttext.lower()):
                            counter = counter + 1
                    overallcounter = (counter/len(postskillslist)) * 100
                    overallcounter = truncate(overallcounter, 2)

                    # CSS class for progress bar
                    cssclass = ''
                    if(overallcounter >= 75):
                        cssclass = 'success'
                    elif(overallcounter < 75 and overallcounter >= 50):
                        cssclass = 'info'
                    elif(overallcounter < 50 and overallcounter >= 25):
                        cssclass = 'warning'
                    elif(overallcounter < 25 and overallcounter >= 0):
                        cssclass = 'danger'

                    # Update list of dictionary
                    matcheddict = {'Name': compnaydetails.fullname, 'Score': overallcounter, 'CanID': post.company_id,'ProgCSS': cssclass, 'CanContact': compnaydetails.mobile, 'CanEmail': compnaydetails.email, 'Title' : post.title, 'Post' : post.post, 'Desc' : post.description} 
                    matcheslist.append(matcheddict)
                passdata['matchedlist'] = matcheslist
        else:
            raise PermissionDenied()
    else:
        return redirect('/')
    return render(request, 'user/index.html', passdata)

def upload(request):
    passdata = {}
    if(request.session.has_key('user_id')):
        if(request.session['role_id'] == 2):
            passdata['fullname'] = request.session['fullname']
            if(request.method == 'POST'):
                resumedoc = request.FILES['txtdoc']
                userid = int(request.session['user_id'])
                getusercounts = Resumes.objects.filter(Q(candidate_id = userid))
                if(getusercounts.count() > 0):
                    resume = Resumes.objects.get(candidate_id = userid)
                    resume.resume_doc = resumedoc
                    resume.save()
                else:
                    resume = Resumes()
                    resume.candidate = AppUsers.objects.get(pk = userid)
                    resume.resume_doc = resumedoc
                    resume.save()
                messages.success(request,'Resume upload.')
                return redirect('/user/')
        else:
            raise PermissionDenied()
    else:
        return redirect('/')
    return render(request, 'user/upload.html', passdata)
