from django.db import models
from account.models import AppUsers

# Create your models here.
class Resumes(models.Model):
    candidate = models.ForeignKey(AppUsers, on_delete=models.CASCADE)
    resume_doc = models.FileField(upload_to='resumes/')
    ondate = models.DateField(auto_now=True)
    score = models.FloatField(null=True)

    class Meta:
        db_table = 'tblresumes'

class Details(models.Model):
    resume = models.ForeignKey(Resumes, on_delete = models.CASCADE)
    name = models.ForeignKey(AppUsers, on_delete = models.CASCADE)
    skills = models.TextField()
    experience = models.FloatField()
    education = models.CharField(max_length = 150)
    email = models.CharField(max_length= 70, default='email')
    mobile = models.CharField(max_length= 15, default='91')
    ondate = models.DateField(auto_now=True)

    class Meta:
        db_table = 'tblrdetails'