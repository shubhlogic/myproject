from django.db import models
from account.models import AppUsers

# Create your models here.
class Posts(models.Model):
    post = models.CharField(max_length = 150)
    title = models.CharField(max_length = 150)
    description = models.TextField()
    ondate = models.DateField(auto_now=True)
    company = models.ForeignKey(AppUsers, on_delete=models.CASCADE)
    skills = models.CharField(max_length = 200)
    education = models.CharField(max_length = 200)
    experience = models.FloatField()

    def __str__(self):
        return self.post

    class Meta:
        db_table = 'tblposts'
