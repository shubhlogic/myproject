import pdftotext
from django.shortcuts import render, redirect, get_object_or_404
from django.db.models import Q
from django.contrib import messages
from django.core.exceptions import PermissionDenied
from admins.models import Categories, Skills
from candidate.models import Resumes, Details
from pyresparser import ResumeParser
from account.models import AppUsers
import os
import nltk
nltk.download('stopwords')
from fuzzywuzzy import fuzz
from company.models import Posts
import docx2txt

# Create your views here.
def index(request):
    passdata = {}
    if(request.session.has_key('user_id')):
        if(request.session['role_id'] == 3):
            passdata['fullname'] = request.session['fullname']
        else:
            raise PermissionDenied()
    else:
        return redirect('/')
    return render(request, 'company/index.html', passdata)

def create(request):
    passdata = {}
    if(request.session.has_key('user_id')):
        if(request.session['role_id'] == 3):
            passdata['posts'] = Posts.objects.filter(Q(company_id = int(request.session['user_id']))).order_by('-id')
            passdata['fullname'] = request.session['fullname']
            if(request.method == 'POST'):
                post = Posts()
                post.post = request.POST['txtpost'].title()
                post.title = request.POST['txttitle'].title()
                post.experience = float(request.POST['txtexp'])
                post.description = request.POST['txtdesc']
                post.skills = request.POST['txtskills']
                post.education = request.POST['txteducation']
                post.company = AppUsers.objects.get(pk = int(request.session['user_id']))
                post.save()
                messages.success(request,'Post created')
                return redirect('/recruiter/create')
        else:
            raise PermissionDenied()
    else:
        return redirect('/')
    return render(request, 'company/create.html', passdata)

# Rounding off the values
def truncate(n, decimals=0):
    multiplier = 10 ** decimals
    return int(n * multiplier) / multiplier

def matcher(request, pk):
    passdata = {}
    if(request.session.has_key('user_id')):
        if(request.session['role_id'] == 3):
            passdata['fullname'] = request.session['fullname']
            postDetails = Posts.objects.get(id = pk)
            passdata['title'] = postDetails.title
            passdata['skills'] = postDetails.skills
            jobskills = postDetails.skills
            jobskillslist = list(jobskills.split(','))
            jobedu = postDetails.education
            jobexp = postDetails.experience

            # Get resume from projects directory
            BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            resumesall = Resumes.objects.all()
            
            matcheslist = []
            filedata = ''
            for res in resumesall:
                candidatedetails = AppUsers.objects.get(pk = res.candidate_id)
                counter = 0
                exttext = ''
                get_path = res.resume_doc.url
                # Get file extension
                filename, file_extension = os.path.splitext(os.path.join(BASE_DIR, get_path[1:]))
                if(file_extension == '.docx'):
                    exttext = docx2txt.process(os.path.join(BASE_DIR, get_path[1:]))

                if(file_extension == '.pdf'):
                    pdf_raw = open(os.path.join(BASE_DIR, get_path[1:]),'rb')
                    pdf_process = pdftotext.PDF(pdf_raw)
                    for pg in pdf_process:
                        exttext += pg
                    pdf_raw.close()

                # filedata += '<br><br>' + exttext

                # Search skill in text
                for skl in jobskillslist:
                    # print(skl.lower())
                    if(skl.lower() in exttext.lower()):
                        counter = counter + 1
                
                overallcounter = (counter/len(jobskillslist)) * 100
                overallcounter = truncate(overallcounter,2)

                # CSS class for progress bar
                cssclass = ''
                if(overallcounter >= 75):
                    cssclass = 'success'
                elif(overallcounter < 75 and overallcounter >= 50):
                    cssclass = 'info'
                elif(overallcounter < 50 and overallcounter >= 25):
                    cssclass = 'warning'
                elif(overallcounter < 25 and overallcounter >= 0):
                    cssclass = 'danger'

                # Update list of dictionary
                matcheddict = {'Name' : candidatedetails.fullname, 'Score' : overallcounter, 'CanID' : res.candidate_id, 'ProgCSS' : cssclass, 'CanContact': candidatedetails.mobile, 'CanEmail' : candidatedetails.email}
                matcheslist.append(matcheddict)
            passdata['matchedlist'] = matcheslist
            passdata['filedata'] = filedata

            # passdata['filedata'] = filedata
        else:
            raise PermissionDenied()
    else:
        return redirect('/')
    return render(request, 'company/matcher.html', passdata)
