from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.db.models import Q
from account.models import Roles, AppUsers

# Create your views here.
def index(request):
    rolescount = Roles.objects.count()
    if(rolescount < 1):
        role = Roles()
        role.name = 'Admin' # System Administrator
        role.save()
        role = Roles()
        role.name = 'User' # Candidate
        role.save()
        role = Roles()
        role.name = 'Company' # Recruiter
        role.save()

    # Add default Admin
    usercount = AppUsers.objects.count()
    if(usercount < 1):
        admin = AppUsers()
        admin.fullname = 'Admin'
        admin.email = 'admin@gmail.com'
        admin.mobile = '9999999999'
        admin.password = 'admin@123'
        admin.role = Roles.objects.get(pk = 1)
        admin.save()

    return redirect('auth')

def auth(request):
    return render(request, 'account/auth.html')

def signup(request):
    if(request.method == 'POST'):
        adduser = AppUsers()
        adduser.fullname = request.POST['txtfullname'].title()
        adduser.mobile = request.POST['txtrmobile']
        adduser.email = request.POST['txtemail']
        adduser.password = request.POST['txtrpassword']
        adduser.role = Roles.objects.get(pk = int(request.POST['txtrole']))
        adduser.save()
        que = AppUsers.objects.filter(mobile = request.POST['txtrmobile'])
        if(que.exists):
            messages.success(request,'Sign up successfully. You can login now.')
        else:
            messages.error(request,'Sign up failed.')
        return redirect('auth')

def login(request):
    if(request.method == 'POST'):
        login = AppUsers.objects.filter(Q(mobile = request.POST['txtmobile']) & Q(password = request.POST['txtpassword']))
        if(login.count() == 1):
            for l in login:
                request.session['user_id'] = l.id
                request.session['fullname'] = l.fullname
                request.session['role_id'] = l.role_id
                print(request.session['fullname'])
            if(request.session['role_id'] == 1):
                return redirect('/admin/')
            elif(request.session['role_id'] == 2):
                return redirect('/user/')
            elif(request.session['role_id'] == 3):
                return redirect('/recruiter/')
        else:
            messages.error(request,'Invalid mobile or password.')
            return redirect('auth')

def logout(request):
    del request.session['fullname']
    del request.session['user_id']
    del request.session['role_id']
    return redirect('/')

