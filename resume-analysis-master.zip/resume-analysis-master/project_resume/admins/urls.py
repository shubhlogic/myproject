from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name = 'index'),
    path('categories', views.categories, name = 'categories'),
    path('skills', views.skills, name = 'skills'),
    path('delete_categories', views.delete_categories, name = 'delete_categories'),
    path('delete_skills', views.delete_skills, name = 'delete_skills'),
]