from django.db import models

# Create your models here.
class Categories(models.Model):
    name = models.CharField(max_length = 50, unique = True)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'tblcategories'

class Skills(models.Model):
    name = models.CharField(max_length = 50)
    category = models.ForeignKey(Categories, on_delete=models.CASCADE)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'tblskills'