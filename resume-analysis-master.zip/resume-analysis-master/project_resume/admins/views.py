from django.shortcuts import render, redirect, get_object_or_404
from django.db.models import Q
from django.contrib import messages
from django.core.exceptions import PermissionDenied
from admins.models import Categories, Skills

# Create your views here.
def index(request):
    passdata = {}
    if(request.session.has_key('user_id')):
        if(request.session['role_id'] == 1):
            passdata['fullname'] = request.session['fullname']
        else:
            raise PermissionDenied()
    else:
        return redirect('/')
    return render(request, 'admin/index.html', passdata)

def categories(request):
    passdata = {}
    if(request.session.has_key('user_id')):
        if(request.session['role_id'] == 1):
            passdata['fullname'] = request.session['fullname']
            # Get count of categories
            cat_count = Categories.objects.count()
            # Add categories if objects are less than 1 i.e. 0
            if(cat_count < 1):
                category = Categories()
                category.name = 'Arts Score'
                category.save()
                category = Categories()
                category.name = 'Engineer Score'
                category.save()
                category = Categories()
                category.name = 'Financial Score'
                category.save()
                category = Categories()
                category.name = 'Management Score'
                category.save()
                category = Categories()
                category.name = 'Programming Score'
                category.save()
                category = Categories()
                category.name = 'Software Score'
                category.save()
            passdata['categories'] = Categories.objects.all().order_by('name')
        else:
            raise PermissionDenied()
    else:
        return redirect('/')
    return render(request, 'admin/categories.html', passdata)

def delete_categories(request):
    if(request.method == 'POST'):
        Categories.objects.all().delete()
        messages.success(request,'All categories deleted.')
        return redirect('/admin/categories')

def skills(request):
    passdata = {}
    if(request.session.has_key('user_id')):
        if(request.session['role_id'] == 1):
            passdata['fullname'] = request.session['fullname']
            passdata['categories'] = Categories.objects.all().order_by('name')
            # Get skills keywords count
            skills_count = Skills.objects.count()
            # Add skills keywords if objects are less than 1 i.e. 0
            if(skills_count < 1):
                programming = ["assembly", "bash", " c " "c++", "c#", "coffeescript", "emacs lisp",
                "go", "groovy", "haskell", "java", "javascript", "matlab", "max MSP", "objective c", 
                "perl", "php","html", "xml", "css", "processing", "python", "ruby", "sml", "swift", 
                "latex" "unity", "unix" "visual basic" "wolfram language", "xquery", "sql", "node.js", 
                "scala", "kdb", "jquery", "mongodb", "asp.net", ".net", "dotnet", "dart", "html5", "css3", "bootstrap", 
                "mean", "angularjs", "reactjs", "android", "kotlin", "xcode", "mysql", "mssql", "mvc", "linq"]

                software = ["computer", "software", "engineering", "computer science", "prototype", "structured design",
                "code development", "communication skills", "problem solving", "software design", "systems", "web", "client",
                "testing", "SDLC", "development process", "database management systems", "web applications", "code"
                "user support", "programming", "developing", "software", "server administration", "machine learning",
                "algorithms", "team", "programming language", "database", "artificial intelligence", "administrator",]

                engineering = ["chemical", "civil", "engineering", "mechanical", "CAD", "design",
                "mechanics", "analysis", "systems", "technical", "autodesk", "inventor", "skills", "realization",
                "technology", "functionality", "hardware", "design process", "process control", "protyping", "team",
                "project conceptualization", "design verification", "project management", "structural design", 
                "build", "modeling", "buildings", "tests", "application", "computer", "information technology"]

                finance = ["financial reporting", "excel", "finance", "trend analysis",
                "financial statement", "result analysis", "strategic planning", "develop trends",
                "DCF", "presentation skills", "team player", "financial analysis", "forecasting",
                "policy development", "business policies", "powerpoint", "microsoft word", "analytical",
                "accounting", "team player", "team", "ability", "accounting", "accountant", "balance sheet",
                "liquidy", "money", "stocks", "office", "microsoft office"]

                management = ["data analysis", "automation", "planning", "ability to plan",
                "customer", "interaction", "consumer", "implement", "analytical", "network",
                "skill analysis", "hiring", "firing", "business development", "contract negotiation",
                "budget", "leadership", "operational development", "evaluations", "management",
                "business", "project planning", "production schedule", "responsibility", "budgeting",
                "optimization", "decision making", "organization", "business"]

                arts = ["performance", "exhibit", "music", "art", "writing", "expressive",
                "editing", "editorial", "social work", "design", "artist", "musician", "collaborative",
                "group", "program", "exhibition", "media", "blog", "journalism", "creative", "innovative",
                "workshop", "master class", "teaching", "lectures", "practice", "studio", "newspaper",
                "english"]

                for item in arts:
                    skill = Skills()
                    skill.name = item
                    skill.category = Categories.objects.get(pk = 13)
                    skill.save()
                
                for item in engineering:
                    skill = Skills()
                    skill.name = item
                    skill.category = Categories.objects.get(pk = 14)
                    skill.save()
              
                for item in finance:
                    skill = Skills()
                    skill.name = item
                    skill.category = Categories.objects.get(pk = 15)
                    skill.save()
                
                for item in management:
                    skill = Skills()
                    skill.name = item
                    skill.category = Categories.objects.get(pk = 16)
                    skill.save()
                
                for item in programming:
                    skill = Skills()
                    skill.name = item
                    skill.category = Categories.objects.get(pk = 17)
                    skill.save()
                    
                for item in software:
                    skill = Skills()
                    skill.name = item
                    skill.category = Categories.objects.get(pk = 18)
                    skill.save()
                    
            passdata['skills'] = Skills.objects.all().order_by('category','name')
        else:
            raise PermissionDenied()
    else:
        return redirect('/')
    return render(request, 'admin/skills.html', passdata)

def delete_skills(request):
    if(request.method == 'POST'):
        Skills.objects.all().delete()
        messages.success(request,'All skills updated.')
        return redirect('/admin/skills')